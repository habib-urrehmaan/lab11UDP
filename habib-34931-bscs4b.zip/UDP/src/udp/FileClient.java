/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package udp;

import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author deser_000
 */
public class FileClient {

    private DatagramSocket socket = null;
    private FileHandler event = null;
    private String sourceFilePath;
    private String destinationPath;
    private String hostName;

    public FileClient() {
        this.hostName = "localHost";
        this.sourceFilePath = "C:/Users/habib/Desktop/habib.zip";
        this.destinationPath = "I:/habib/";
    }

    public void createConnection() {
        try {
            //send the file out to the server
            int i=0;
            socket = new DatagramSocket();
            int size=1;
            int start=0;
            InetAddress IPAddress = InetAddress.getByName(hostName);
            byte[] incomingData = new byte[1024];
            //The file that is to be sent
            //run till the file entirely received at Server
            event = getFileHandler();
            
            //send the file
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            ObjectOutputStream os = new ObjectOutputStream(outputStream);
            //for (i=0;i<event.getFileSize();i++)
            if (event.getFileSize()>1024)
            {
                size=(int) event.getFileSize()/1024;
            
            for (i=0;i<size;i++)
            {    
                os.writeObject(Arrays.copyOfRange(event.getFileData(),0,start+=1024));
                byte[] data = outputStream.toByteArray();
                DatagramPacket sendPacket = new DatagramPacket(data, data.length, IPAddress, 9876);
                socket.send(sendPacket);
                System.out.println("File sent from client");
            }
            }
            else
            {
                os.writeObject(event);
                byte[] data = outputStream.toByteArray();
                DatagramPacket sendPacket = new DatagramPacket(data, data.length, IPAddress, 9876);
                socket.send(sendPacket);
                System.out.println("File sent from client");
            }
            //receive confirmation
            DatagramPacket incomingPacket = new DatagramPacket(incomingData, incomingData.length);
            socket.receive(incomingPacket);
            String response = new String(incomingPacket.getData());
            System.out.println(response);
            
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public FileHandler getFileHandler() throws IOException {
        FileHandler  fileHandle = new FileHandler();
        /*System.out.println("Enter Path of the file");
        Scanner input=new Scanner(System.in);
        sourceFilePath=input.nextLine();*/
        
        String fileName = sourceFilePath.substring(sourceFilePath.lastIndexOf("/") + 1, sourceFilePath.length());
        String sourcepath = sourceFilePath.substring(0, sourceFilePath.lastIndexOf("/") + 1);
        
        fileHandle.setSourceDirectory(sourcepath);
        Path Path = Paths.get(sourceFilePath);
        File file = Path.toFile();
        fileHandle.setFilename(fileName);
        
        if (file.isFile()) {
            try {
                //Read the file and build the file handle
                fileHandle.setSourceDirectory(sourceFilePath);
                byte[] ba = Files.readAllBytes(Path);
                fileHandle.setFileData(ba);
                fileHandle.setDestinationDirectory(destinationPath);
                fileHandle.setStatus("nonWritable");
                fileHandle.setFileSize(file.length());
                
                
                
                
                
            } catch (Exception e) {
                e.printStackTrace();
                 fileHandle.setStatus("Error");
            }
        } else {
            System.out.println("path specified is not pointing to a file");
             fileHandle.setStatus("Error");
        }
        return  fileHandle;
    }

    public static void main(String[] args) {
        FileClient client = new FileClient();
        client.createConnection();
    }

}
